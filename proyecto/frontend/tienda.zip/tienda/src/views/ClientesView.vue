<script>
import { RouterLink } from "vue-router";
</script>

<template>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h4>Clientes</h4>
                <RouterLink to="/clientes/create" class="btn btn-primary float-end">
                    Agregar
                </RouterLink>
            </div>
            <div class="card-body">
                hola
            </div>
        </div>

    </div>
</template>